﻿--
-- PostgreSQL database dump
--

\restrict kvkr9UJQu5YjtO9Dac62QjgIbr7EZZX0BRQHDGC6ZhVRbmdsek6bTV8T6ueDv1a

-- Dumped from database version 15.17 (Debian 15.17-1.pgdg13+1)
-- Dumped by pg_dump version 15.17 (Debian 15.17-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS '';


--
-- Name: ExperienceLevel; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ExperienceLevel" AS ENUM (
    'INICIANTE',
    'INTERMEDIARIO',
    'PROFISSIONAL',
    'ELITE'
);


--
-- Name: Region; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."Region" AS ENUM (
    'ZN',
    'ZS',
    'ZO',
    'BAIXADA',
    'INTER'
);


--
-- Name: RideOfferStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."RideOfferStatus" AS ENUM (
    'PENDING',
    'ACCEPTED',
    'REJECTED',
    'EXPIRED'
);


--
-- Name: RideStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."RideStatus" AS ENUM (
    'PENDING',
    'MATCHING',
    'WAITING_DRIVER',
    'ACCEPTED',
    'REJECTED',
    'EXPIRED',
    'IN_PROGRESS',
    'COMPLETED',
    'CANCELLED',
    'WAITING_REFERRAL'
);


--
-- Name: UserRole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."UserRole" AS ENUM (
    'DRIVER',
    'PASSENGER'
);


--
-- Name: VehicleCategory; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."VehicleCategory" AS ENUM (
    'CONFORTO',
    'EXECUTIVO'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Driver; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Driver" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "experienceLevel" public."ExperienceLevel" NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "referralCode" text NOT NULL,
    "networkLevel" integer DEFAULT 0 NOT NULL,
    "referredByDriverId" text,
    "publicSlug" text,
    regions text[]
);


--
-- Name: DriverAvailability; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."DriverAvailability" (
    id text NOT NULL,
    "driverId" text NOT NULL,
    "dayOfWeek" integer NOT NULL,
    "startTime" text NOT NULL,
    "endTime" text NOT NULL
);


--
-- Name: DriverReferral; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."DriverReferral" (
    id text NOT NULL,
    "referredDriverId" text NOT NULL,
    level integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "driverId" text NOT NULL
);


--
-- Name: Passenger; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Passenger" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "referredByDriverId" text
);


--
-- Name: RideOffer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."RideOffer" (
    id text NOT NULL,
    "rideRequestId" text NOT NULL,
    "driverId" text NOT NULL,
    status public."RideOfferStatus" DEFAULT 'PENDING'::public."RideOfferStatus" NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "respondedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: RideRequest; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."RideRequest" (
    id text NOT NULL,
    "passengerId" text NOT NULL,
    origin text NOT NULL,
    destination text NOT NULL,
    "scheduledAt" timestamp(3) without time zone NOT NULL,
    status public."RideStatus" DEFAULT 'PENDING'::public."RideStatus" NOT NULL,
    "selectedDriverId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "destinationLat" double precision,
    "destinationLng" double precision,
    "distanceKm" double precision,
    "durationMin" integer,
    "originLat" double precision,
    "originLng" double precision,
    "priceEstimated" double precision,
    "priceOffered" double precision,
    context jsonb
);


--
-- Name: User; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."User" (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text NOT NULL,
    role public."UserRole" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "passwordHash" text
);


--
-- Name: Vehicle; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Vehicle" (
    id text NOT NULL,
    "driverId" text NOT NULL,
    model text NOT NULL,
    brand text NOT NULL,
    plate text NOT NULL,
    category public."VehicleCategory" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: Driver; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Driver" (id, "userId", "experienceLevel", "isActive", "createdAt", "referralCode", "networkLevel", "referredByDriverId", "publicSlug", regions) FROM stdin;
7d4455cc-366b-4f3e-ae1f-2da8681ab802	d2b73120-70fe-4e63-85ba-f7fea8cd8a05	PROFISSIONAL	t	2026-05-16 01:42:19.607	joao-luiz-correa-de-brito-zn	1	983cdb75-f98d-43c6-b6a1-7127cd6b0bfe	joao-luiz-barra	{"Zona Oeste",Barra,Recreio}
b4f004ed-c4e4-49f4-ac91-eda9e0303f41	b9b3d361-5420-4b85-b930-49a22c14a458	INTERMEDIARIO	t	2026-05-16 01:42:19.649	carlinhos-zn	2	7d4455cc-366b-4f3e-ae1f-2da8681ab802	carlinhos-city	{"Zona Sul","Zona Oeste",Centro}
821cf16f-85a9-457d-aa6b-727d9f93c867	42997f1d-4f9f-4867-b4a3-397b9aaea2bd	INTERMEDIARIO	t	2026-05-16 01:42:19.677	jenner-zn	2	7d4455cc-366b-4f3e-ae1f-2da8681ab802	jenner-spin	{Baixada,"Zona Norte",Centro}
338b7693-92aa-4209-a9a4-bdb34d9d8f8e	6599d58e-eedd-4d79-9736-6b0f61d68715	INICIANTE	t	2026-05-16 01:42:19.705	bira-zn	2	7d4455cc-366b-4f3e-ae1f-2da8681ab802	bira-onix-ltz	{"Zona Norte",Centro,"Zona Oeste"}
c021a9d8-59a0-4c79-b812-dda204769593	52d50712-5d02-4f34-9dc2-b011674e694f	PROFISSIONAL	t	2026-05-16 01:42:19.729	gisele-zn	2	7d4455cc-366b-4f3e-ae1f-2da8681ab802	gisele-malibu-208	{"Zona Sul",Centro,Niteroi}
9e345ac5-6d3d-406b-b953-600a60e32e38	79bf9a3f-ef21-42b9-b40f-7f6395049ebf	INTERMEDIARIO	t	2026-05-16 01:42:19.762	fabio-zn	2	7d4455cc-366b-4f3e-ae1f-2da8681ab802	fabio-tcross	{"Zona Oeste",Intermunicipal,"Regiao dos Lagos"}
04c76ac3-1475-4f40-a1a2-34e2abf7a65a	190f59f4-c1d7-4307-a5a5-374f3e4e802e	PROFISSIONAL	t	2026-05-16 01:42:19.796	andre-cabral-zn	2	7d4455cc-366b-4f3e-ae1f-2da8681ab802	andre-cabral-etios	{Centro,"Zona Norte","Sao Goncalo"}
eeb3f3f4-805d-4e68-a10b-94f8c9a9caef	80c1049c-6bf3-4988-8da9-14f5a0d6c473	PROFISSIONAL	t	2026-05-16 01:42:19.832	anselmo-valle-dos-santos-zn	1	983cdb75-f98d-43c6-b6a1-7127cd6b0bfe	anselmo-valle	{Niteroi,"Sao Goncalo",Intermunicipal}
cf9edaf2-63d3-4be8-9c01-fb1f6d09072a	fa1990a6-bb52-4c75-8a65-f7f5611cfa99	PROFISSIONAL	t	2026-05-16 01:42:19.858	fernando-barreira-zn	1	983cdb75-f98d-43c6-b6a1-7127cd6b0bfe	fernando-barreira	{Baixada,"Zona Norte","Regiao dos Lagos"}
983cdb75-f98d-43c6-b6a1-7127cd6b0bfe	76d3739e-c031-43d6-8915-7c85fe303438	PROFISSIONAL	t	2026-05-16 01:42:19.562	pedro-paulo-motta-zn	0	\N	pedro-paulo-motta	{"Zona Oeste",Centro,"Zona Sul",Intermunicipal}
\.


--
-- Data for Name: DriverAvailability; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."DriverAvailability" (id, "driverId", "dayOfWeek", "startTime", "endTime") FROM stdin;
\.


--
-- Data for Name: DriverReferral; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."DriverReferral" (id, "referredDriverId", level, "createdAt", "driverId") FROM stdin;
e79997d1-a358-49e9-b900-9e03c4d07235	eeb3f3f4-805d-4e68-a10b-94f8c9a9caef	1	2026-05-16 01:42:20.007	983cdb75-f98d-43c6-b6a1-7127cd6b0bfe
0b455f01-0beb-42bf-a92e-4830f44a9e76	7d4455cc-366b-4f3e-ae1f-2da8681ab802	1	2026-05-16 01:42:19.88	983cdb75-f98d-43c6-b6a1-7127cd6b0bfe
08111ce7-0dcd-49e3-a84b-dfa79a5c450f	b4f004ed-c4e4-49f4-ac91-eda9e0303f41	1	2026-05-16 01:42:19.89	7d4455cc-366b-4f3e-ae1f-2da8681ab802
98877599-d165-48a9-b4aa-20112bcfaee9	b4f004ed-c4e4-49f4-ac91-eda9e0303f41	2	2026-05-16 01:42:19.894	983cdb75-f98d-43c6-b6a1-7127cd6b0bfe
ca7a9333-c918-4217-864b-00650127f51e	821cf16f-85a9-457d-aa6b-727d9f93c867	1	2026-05-16 01:42:19.903	7d4455cc-366b-4f3e-ae1f-2da8681ab802
bbbf406d-fa7c-433f-995f-434d6a963001	821cf16f-85a9-457d-aa6b-727d9f93c867	2	2026-05-16 01:42:19.909	983cdb75-f98d-43c6-b6a1-7127cd6b0bfe
90c3fc2d-c53e-4830-924f-d94224d7b2e1	338b7693-92aa-4209-a9a4-bdb34d9d8f8e	1	2026-05-16 01:42:19.93	7d4455cc-366b-4f3e-ae1f-2da8681ab802
62a952b0-ca63-4ecb-8a1b-561da4f4c535	338b7693-92aa-4209-a9a4-bdb34d9d8f8e	2	2026-05-16 01:42:19.935	983cdb75-f98d-43c6-b6a1-7127cd6b0bfe
35b518b5-c18b-4c47-8e76-ed4761a843c2	c021a9d8-59a0-4c79-b812-dda204769593	1	2026-05-16 01:42:19.944	7d4455cc-366b-4f3e-ae1f-2da8681ab802
98fed8c3-61e6-4f96-9ab0-068ac1cac099	c021a9d8-59a0-4c79-b812-dda204769593	2	2026-05-16 01:42:19.948	983cdb75-f98d-43c6-b6a1-7127cd6b0bfe
6e18fbe3-6329-4e9b-81f2-881466316606	9e345ac5-6d3d-406b-b953-600a60e32e38	1	2026-05-16 01:42:19.956	7d4455cc-366b-4f3e-ae1f-2da8681ab802
475f87eb-c087-4638-ba51-e7e2e4f910e4	9e345ac5-6d3d-406b-b953-600a60e32e38	2	2026-05-16 01:42:19.979	983cdb75-f98d-43c6-b6a1-7127cd6b0bfe
bc5df66e-0ff1-4269-b563-4ceb8bd4bec2	04c76ac3-1475-4f40-a1a2-34e2abf7a65a	1	2026-05-16 01:42:19.992	7d4455cc-366b-4f3e-ae1f-2da8681ab802
ddd5259e-e3af-4cae-8370-d3e888cd05ac	04c76ac3-1475-4f40-a1a2-34e2abf7a65a	2	2026-05-16 01:42:19.997	983cdb75-f98d-43c6-b6a1-7127cd6b0bfe
5ff6911d-1e44-4d37-8e93-338c23b3c735	cf9edaf2-63d3-4be8-9c01-fb1f6d09072a	1	2026-05-16 01:42:20.016	983cdb75-f98d-43c6-b6a1-7127cd6b0bfe
\.


--
-- Data for Name: Passenger; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Passenger" (id, "userId", "referredByDriverId") FROM stdin;
93a9e5a8-dcb4-49ef-86a7-c03d1e41913d	dc9f3180-eb22-442c-8597-35845cc20426	983cdb75-f98d-43c6-b6a1-7127cd6b0bfe
1e7669d3-86e4-48ed-8fdc-6c89f02846c1	84c9e1e9-e082-4c9b-8a2d-61378db2a2e6	983cdb75-f98d-43c6-b6a1-7127cd6b0bfe
1fd0eab7-4968-4752-8fca-ea61b8aa23d6	2672e6c6-01d8-4d40-afaf-60e6ed3bbc16	983cdb75-f98d-43c6-b6a1-7127cd6b0bfe
bc995204-a66a-4fb4-8ca2-d9209c2a6184	7ee56fe4-184b-487a-8424-167e93e6610c	983cdb75-f98d-43c6-b6a1-7127cd6b0bfe
\.


--
-- Data for Name: RideOffer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."RideOffer" (id, "rideRequestId", "driverId", status, "expiresAt", "respondedAt", "createdAt") FROM stdin;
6d4a11bf-4a0a-458a-9e7a-f05a27c47775	2bdac88b-5ad0-4cdd-8a82-d7e0590a4e41	983cdb75-f98d-43c6-b6a1-7127cd6b0bfe	ACCEPTED	2026-05-16 13:25:15.701	2026-05-16 13:23:33.328	2026-05-16 13:23:15.708
1bb1d71a-abff-4a99-b2f3-2645c89ab31c	b6f64268-f1f6-4ea6-9b81-7c3e203eb3e5	983cdb75-f98d-43c6-b6a1-7127cd6b0bfe	EXPIRED	2026-05-16 15:16:40.689	\N	2026-05-16 15:14:40.698
c92ab41f-7647-4979-b980-cc440f277adf	b6f64268-f1f6-4ea6-9b81-7c3e203eb3e5	eeb3f3f4-805d-4e68-a10b-94f8c9a9caef	EXPIRED	2026-05-16 15:21:40.724	\N	2026-05-16 15:19:40.736
e61dbf10-dc55-40f1-ab5d-d3901b550ef9	b6f64268-f1f6-4ea6-9b81-7c3e203eb3e5	7d4455cc-366b-4f3e-ae1f-2da8681ab802	EXPIRED	2026-05-16 15:21:40.724	\N	2026-05-16 15:19:40.74
a784bccc-26ed-4159-800a-60c947c814c8	b6f64268-f1f6-4ea6-9b81-7c3e203eb3e5	cf9edaf2-63d3-4be8-9c01-fb1f6d09072a	EXPIRED	2026-05-16 15:21:40.724	\N	2026-05-16 15:19:40.743
a8969371-bfa0-4165-a285-153bcefb45c6	b6f64268-f1f6-4ea6-9b81-7c3e203eb3e5	b4f004ed-c4e4-49f4-ac91-eda9e0303f41	EXPIRED	2026-05-16 15:21:40.724	\N	2026-05-16 15:19:40.746
7bd34a5b-2a14-4d55-9eba-834007ea4b7a	b6f64268-f1f6-4ea6-9b81-7c3e203eb3e5	821cf16f-85a9-457d-aa6b-727d9f93c867	EXPIRED	2026-05-16 15:21:40.724	\N	2026-05-16 15:19:40.749
8f29f245-a56c-40ed-9e8c-9e1d3f24ea7b	b6f64268-f1f6-4ea6-9b81-7c3e203eb3e5	338b7693-92aa-4209-a9a4-bdb34d9d8f8e	EXPIRED	2026-05-16 15:21:40.724	\N	2026-05-16 15:19:40.752
9af2a653-5c6a-4092-a39b-e38b9fd966f2	b6f64268-f1f6-4ea6-9b81-7c3e203eb3e5	c021a9d8-59a0-4c79-b812-dda204769593	EXPIRED	2026-05-16 15:21:40.724	\N	2026-05-16 15:19:40.755
f5b30e21-fc48-40b7-bf49-17c92d65ded1	b6f64268-f1f6-4ea6-9b81-7c3e203eb3e5	9e345ac5-6d3d-406b-b953-600a60e32e38	EXPIRED	2026-05-16 15:21:40.724	\N	2026-05-16 15:19:40.758
623eed7e-717a-411e-9024-f6f0689cd93c	b6f64268-f1f6-4ea6-9b81-7c3e203eb3e5	04c76ac3-1475-4f40-a1a2-34e2abf7a65a	EXPIRED	2026-05-16 15:21:40.724	\N	2026-05-16 15:19:40.762
bfcf4279-d07c-47a2-9764-cf42f959381d	ce61354d-5117-42d5-af05-5b35f9e23144	983cdb75-f98d-43c6-b6a1-7127cd6b0bfe	EXPIRED	2026-05-16 18:50:19.91	\N	2026-05-16 18:48:19.913
8dd7a804-e7c2-4dd4-843c-b3f4a1f7db3c	ce61354d-5117-42d5-af05-5b35f9e23144	eeb3f3f4-805d-4e68-a10b-94f8c9a9caef	EXPIRED	2026-05-16 18:55:19.968	\N	2026-05-16 18:53:19.98
e97ba137-ab46-46a2-af89-d3064e62faf5	ce61354d-5117-42d5-af05-5b35f9e23144	7d4455cc-366b-4f3e-ae1f-2da8681ab802	EXPIRED	2026-05-16 18:55:19.968	\N	2026-05-16 18:53:19.983
94a989ad-2506-471b-a8c4-56737698e422	ce61354d-5117-42d5-af05-5b35f9e23144	cf9edaf2-63d3-4be8-9c01-fb1f6d09072a	EXPIRED	2026-05-16 18:55:19.968	\N	2026-05-16 18:53:19.987
7ac8f7bb-1eae-4229-9739-d03e3ab09d6e	ce61354d-5117-42d5-af05-5b35f9e23144	b4f004ed-c4e4-49f4-ac91-eda9e0303f41	EXPIRED	2026-05-16 18:55:19.968	\N	2026-05-16 18:53:19.99
1f31eb03-f664-46e2-aa94-ace2314368e3	ce61354d-5117-42d5-af05-5b35f9e23144	821cf16f-85a9-457d-aa6b-727d9f93c867	EXPIRED	2026-05-16 18:55:19.968	\N	2026-05-16 18:53:19.993
9f956993-59c3-4673-82f0-9f838f260063	ce61354d-5117-42d5-af05-5b35f9e23144	338b7693-92aa-4209-a9a4-bdb34d9d8f8e	EXPIRED	2026-05-16 18:55:19.968	\N	2026-05-16 18:53:19.996
4b8a6135-4870-4d8a-a660-d61238dd5b51	ce61354d-5117-42d5-af05-5b35f9e23144	c021a9d8-59a0-4c79-b812-dda204769593	EXPIRED	2026-05-16 18:55:19.968	\N	2026-05-16 18:53:19.999
2ae21fcb-8e5b-4f02-aa83-9fd96de78c5a	ce61354d-5117-42d5-af05-5b35f9e23144	9e345ac5-6d3d-406b-b953-600a60e32e38	EXPIRED	2026-05-16 18:55:19.968	\N	2026-05-16 18:53:20.002
48e7877d-3e91-4c62-9a78-70c42cc07819	ce61354d-5117-42d5-af05-5b35f9e23144	04c76ac3-1475-4f40-a1a2-34e2abf7a65a	EXPIRED	2026-05-16 18:55:19.968	\N	2026-05-16 18:53:20.005
\.


--
-- Data for Name: RideRequest; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."RideRequest" (id, "passengerId", origin, destination, "scheduledAt", status, "selectedDriverId", "createdAt", "destinationLat", "destinationLng", "distanceKm", "durationMin", "originLat", "originLng", "priceEstimated", "priceOffered", context) FROM stdin;
ce61354d-5117-42d5-af05-5b35f9e23144	bc995204-a66a-4fb4-8ca2-d9209c2a6184	Rua  projetada c  336 casa 56	Rua Dedret  23 castelo	2026-05-16 20:30:00	EXPIRED	\N	2026-05-16 18:48:19.886	\N	\N	\N	\N	\N	\N	\N	\N	{"isPet": false, "isVip": false, "isAirport": false, "isLuggage": false}
2bdac88b-5ad0-4cdd-8a82-d7e0590a4e41	93a9e5a8-dcb4-49ef-86a7-c03d1e41913d	Rua A 56 Tijuca Rio de Janeiro	Rua B Barra da Tijuca Rio de Janeiro	2026-05-19 13:23:00	ACCEPTED	983cdb75-f98d-43c6-b6a1-7127cd6b0bfe	2026-05-16 13:23:15.684	\N	\N	\N	\N	\N	\N	\N	\N	{"isPet": false, "isVip": true, "isAirport": false, "isLuggage": false}
b6f64268-f1f6-4ea6-9b81-7c3e203eb3e5	1e7669d3-86e4-48ed-8fdc-6c89f02846c1	Meier	Aeroporto galeao	2026-05-16 21:15:00	EXPIRED	\N	2026-05-16 15:14:40.667	\N	\N	\N	\N	\N	\N	\N	\N	{"isPet": false, "isVip": false, "isAirport": false, "isLuggage": false}
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."User" (id, name, email, phone, role, "createdAt", "passwordHash") FROM stdin;
dc9f3180-eb22-442c-8597-35845cc20426	Teste Pedro passageiro 	testepedropassageiro@gmail.com	21995623333	PASSENGER	2026-05-16 13:21:08.545	$2b$10$eLaH4oGO9YBBURvni1fI9uTWivhwGspnYMKRwr.BHQ5v2siGPMOWi
84c9e1e9-e082-4c9b-8a2d-61378db2a2e6	Anselmo valle	ansvalle@gmail.com	21999990017	PASSENGER	2026-05-16 15:13:39.829	$2b$10$ZS54LSgzejEDKKQ0.wGuPu/FhJZqEiF5Nde1XLj2aM1Gj5gnYf4Di
2672e6c6-01d8-4d40-afaf-60e6ed3bbc16	MARIA LUCIA DE SOUZA	tialuciamusic2014@gmail.com	5568642002	PASSENGER	2026-05-16 15:31:53.451	$2b$10$llPKLvcjfN5Z8/ZR72/rv.R7CqZUtZBr6yZOPmSEQLir26SgwMwtG
7ee56fe4-184b-487a-8424-167e93e6610c	ANA CLAUDIA ELIAS DA SILVA	acedasilva70@gmail.com	55219747718	PASSENGER	2026-05-16 18:46:17.341	$2b$10$iIya5uqLc1A37.dDRToD5ezin6z.tLBsSDgsrzMQOrweJVF2yDf3K
76d3739e-c031-43d6-8915-7c85fe303438	Pedro Paulo Motta	mottapedro01@gmail.com	21981722517	DRIVER	2026-05-16 01:42:19.549	$2b$10$oSTUxHDfXTsVNyOkBjQaqeNrPqbA.MWrzu4LV12I7Ohc94XQuHWbK
d2b73120-70fe-4e63-85ba-f7fea8cd8a05	Jo├úo Luiz Correa de Brito	jlcbrito@driver.com	11999990004	DRIVER	2026-05-16 01:42:19.599	$2b$10$oSTUxHDfXTsVNyOkBjQaqeNrPqbA.MWrzu4LV12I7Ohc94XQuHWbK
b9b3d361-5420-4b85-b930-49a22c14a458	Carlinhos	carlinhos@driver.com	21999990011	DRIVER	2026-05-16 01:42:19.636	$2b$10$oSTUxHDfXTsVNyOkBjQaqeNrPqbA.MWrzu4LV12I7Ohc94XQuHWbK
42997f1d-4f9f-4867-b4a3-397b9aaea2bd	Jenner	jenner@driver.com	21999990012	DRIVER	2026-05-16 01:42:19.67	$2b$10$oSTUxHDfXTsVNyOkBjQaqeNrPqbA.MWrzu4LV12I7Ohc94XQuHWbK
6599d58e-eedd-4d79-9736-6b0f61d68715	Bira	bira@driver.com	21999990013	DRIVER	2026-05-16 01:42:19.697	$2b$10$oSTUxHDfXTsVNyOkBjQaqeNrPqbA.MWrzu4LV12I7Ohc94XQuHWbK
52d50712-5d02-4f34-9dc2-b011674e694f	Gisele	gisele@driver.com	21999990014	DRIVER	2026-05-16 01:42:19.723	$2b$10$oSTUxHDfXTsVNyOkBjQaqeNrPqbA.MWrzu4LV12I7Ohc94XQuHWbK
79bf9a3f-ef21-42b9-b40f-7f6395049ebf	F├íbio	fabio@driver.com	21999990015	DRIVER	2026-05-16 01:42:19.749	$2b$10$oSTUxHDfXTsVNyOkBjQaqeNrPqbA.MWrzu4LV12I7Ohc94XQuHWbK
190f59f4-c1d7-4307-a5a5-374f3e4e802e	Andr├® Cabral	andre.cabral@driver.com	21999990016	DRIVER	2026-05-16 01:42:19.787	$2b$10$oSTUxHDfXTsVNyOkBjQaqeNrPqbA.MWrzu4LV12I7Ohc94XQuHWbK
80c1049c-6bf3-4988-8da9-14f5a0d6c473	Anselmo Valle dos Santos	anselmo@driver.com	21999990017	DRIVER	2026-05-16 01:42:19.823	$2b$10$oSTUxHDfXTsVNyOkBjQaqeNrPqbA.MWrzu4LV12I7Ohc94XQuHWbK
fa1990a6-bb52-4c75-8a65-f7f5611cfa99	Fernando Barreira	fernando.barreira@driver.com	21999990018	DRIVER	2026-05-16 01:42:19.852	$2b$10$oSTUxHDfXTsVNyOkBjQaqeNrPqbA.MWrzu4LV12I7Ohc94XQuHWbK
\.


--
-- Data for Name: Vehicle; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Vehicle" (id, "driverId", model, brand, plate, category, "createdAt") FROM stdin;
80971066-5907-4e51-abf6-ce64adca7d1d	983cdb75-f98d-43c6-b6a1-7127cd6b0bfe	Onix Plus Turbo	Chevrolet	RJS1234	EXECUTIVO	2026-05-16 01:42:19.576
f8d3c56a-ed7d-482b-8b5d-d8690a651d93	7d4455cc-366b-4f3e-ae1f-2da8681ab802	Logan	Renault	UABC1234	CONFORTO	2026-05-16 01:42:19.614
c11d2a04-5bf1-4552-bb30-e4b8cbbf9268	b4f004ed-c4e4-49f4-ac91-eda9e0303f41	Argo	Fiat	ALI1001	CONFORTO	2026-05-16 01:42:19.659
90e6b3ef-6540-4bc6-bb89-87d75e0bb712	821cf16f-85a9-457d-aa6b-727d9f93c867	Cronos	Fiat	ALI1002	CONFORTO	2026-05-16 01:42:19.687
a6a4316a-2330-4107-8a91-75d8c52ee410	338b7693-92aa-4209-a9a4-bdb34d9d8f8e	Voyage	Volkswagen	ALI1003	CONFORTO	2026-05-16 01:42:19.712
e645ef3d-eccf-4342-b276-8b6da50665be	c021a9d8-59a0-4c79-b812-dda204769593	Yaris	Toyota	ALI1004	EXECUTIVO	2026-05-16 01:42:19.736
382ad123-865f-4d5b-903a-3a0041b9aa72	9e345ac5-6d3d-406b-b953-600a60e32e38	Polo	Volkswagen	ALI1005	CONFORTO	2026-05-16 01:42:19.773
60e0a045-ddc9-42dd-8fa6-a203b31eb8b0	04c76ac3-1475-4f40-a1a2-34e2abf7a65a	Versa	Nissan	ALI1006	EXECUTIVO	2026-05-16 01:42:19.809
0faa925b-cf79-46ce-838e-2a551ba7a373	eeb3f3f4-805d-4e68-a10b-94f8c9a9caef	Kicks	Nissan	ALI1007	EXECUTIVO	2026-05-16 01:42:19.841
d00f08df-62da-4a3f-905b-bc29f4a54afc	cf9edaf2-63d3-4be8-9c01-fb1f6d09072a	Sentra	Nissan	ALI1008	EXECUTIVO	2026-05-16 01:42:19.863
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
abbb1fb4-84d1-4413-8a00-5411780ce933	a17b09d00448bbf0ba53013a80cf131539748847c351444364fbc01095dea544	2026-05-11 18:51:05.03372+00	20260421003315_init	\N	\N	2026-05-11 18:51:04.745128+00	1
b106abac-9388-4a4d-b213-cc7bc2315bf1	a933c0e8127257df6ca93d378d3fb9391eafff5fb36e759a8a6ea53dce32aece	2026-05-11 18:51:05.048073+00	20260422015353_add_ride_metrics	\N	\N	2026-05-11 18:51:05.038245+00	1
0464d365-c819-48f9-86d9-928c0cbbcb18	1f0a09947e69a721f90e14fbfeba3a672e3461e6a6f43ba3381e83c57f62577a	2026-05-11 18:51:05.065432+00	20260423140951_add_driver_network	\N	\N	2026-05-11 18:51:05.051895+00	1
097ecc4d-bfc1-4d42-8838-1bbd4bf97563	aff5e7007a59911f669fca76af59d1ae9e1087fdcd41ee6fedf452669ad5a623	2026-05-11 18:51:05.083665+00	20260425105032_add_ride_context	\N	\N	2026-05-11 18:51:05.068592+00	1
fb34e379-e2a3-4e44-b2b9-ef919efc5671	d8d843499a0b3b883258d3aa4a1880945fe27a56738a96f8eb8dda7d332d5a9b	2026-05-11 18:51:05.099735+00	20260427135402_add_waiting_referral_status	\N	\N	2026-05-11 18:51:05.088234+00	1
45f39571-6f57-4620-9ec4-0d2d217ce56b	ed064c7a8f1a95f2e04e985fbf4d2fa3cf576230e128498f103e34e506537727	2026-05-11 18:51:05.183036+00	20260429020039_add_driver_referral	\N	\N	2026-05-11 18:51:05.104154+00	1
bc01e8ff-0eba-4b4c-97f2-8e210cdfa9b2	3c486c8800c5b58d70c40bbc00e6f7cf7cdb2c6be5e97c1b84b28b256d75d9d8	2026-05-11 18:51:05.210089+00	20260429021936_add_referral_index	\N	\N	2026-05-11 18:51:05.186655+00	1
215f45b8-01ef-4aae-a305-152de1353f6f	18a65d6320d16683c675dfdde1f9a933ee28a28a5f6ac2284c348cdb83b6ac5c	2026-05-11 18:51:05.239702+00	20260509000000_add_driver_referral_code	\N	\N	2026-05-11 18:51:05.212985+00	1
\.


--
-- Name: DriverAvailability DriverAvailability_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DriverAvailability"
    ADD CONSTRAINT "DriverAvailability_pkey" PRIMARY KEY (id);


--
-- Name: DriverReferral DriverReferral_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DriverReferral"
    ADD CONSTRAINT "DriverReferral_pkey" PRIMARY KEY (id);


--
-- Name: Driver Driver_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Driver"
    ADD CONSTRAINT "Driver_pkey" PRIMARY KEY (id);


--
-- Name: Passenger Passenger_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Passenger"
    ADD CONSTRAINT "Passenger_pkey" PRIMARY KEY (id);


--
-- Name: RideOffer RideOffer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RideOffer"
    ADD CONSTRAINT "RideOffer_pkey" PRIMARY KEY (id);


--
-- Name: RideRequest RideRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RideRequest"
    ADD CONSTRAINT "RideRequest_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: Vehicle Vehicle_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Vehicle"
    ADD CONSTRAINT "Vehicle_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: DriverReferral_driverId_referredDriverId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "DriverReferral_driverId_referredDriverId_key" ON public."DriverReferral" USING btree ("driverId", "referredDriverId");


--
-- Name: Driver_publicSlug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Driver_publicSlug_key" ON public."Driver" USING btree ("publicSlug");


--
-- Name: Driver_referralCode_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Driver_referralCode_key" ON public."Driver" USING btree ("referralCode");


--
-- Name: Driver_userId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Driver_userId_key" ON public."Driver" USING btree ("userId");


--
-- Name: Passenger_userId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Passenger_userId_key" ON public."Passenger" USING btree ("userId");


--
-- Name: RideOffer_driverId_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "RideOffer_driverId_status_idx" ON public."RideOffer" USING btree ("driverId", status);


--
-- Name: RideOffer_rideRequestId_driverId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "RideOffer_rideRequestId_driverId_key" ON public."RideOffer" USING btree ("rideRequestId", "driverId");


--
-- Name: RideRequest_scheduledAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "RideRequest_scheduledAt_idx" ON public."RideRequest" USING btree ("scheduledAt");


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: Vehicle_plate_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Vehicle_plate_key" ON public."Vehicle" USING btree (plate);


--
-- Name: DriverAvailability DriverAvailability_driverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DriverAvailability"
    ADD CONSTRAINT "DriverAvailability_driverId_fkey" FOREIGN KEY ("driverId") REFERENCES public."Driver"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DriverReferral DriverReferral_driverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DriverReferral"
    ADD CONSTRAINT "DriverReferral_driverId_fkey" FOREIGN KEY ("driverId") REFERENCES public."Driver"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DriverReferral DriverReferral_referredDriverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DriverReferral"
    ADD CONSTRAINT "DriverReferral_referredDriverId_fkey" FOREIGN KEY ("referredDriverId") REFERENCES public."Driver"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Driver Driver_referredByDriverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Driver"
    ADD CONSTRAINT "Driver_referredByDriverId_fkey" FOREIGN KEY ("referredByDriverId") REFERENCES public."Driver"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Driver Driver_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Driver"
    ADD CONSTRAINT "Driver_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Passenger Passenger_referredByDriverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Passenger"
    ADD CONSTRAINT "Passenger_referredByDriverId_fkey" FOREIGN KEY ("referredByDriverId") REFERENCES public."Driver"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Passenger Passenger_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Passenger"
    ADD CONSTRAINT "Passenger_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RideOffer RideOffer_driverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RideOffer"
    ADD CONSTRAINT "RideOffer_driverId_fkey" FOREIGN KEY ("driverId") REFERENCES public."Driver"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RideOffer RideOffer_rideRequestId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RideOffer"
    ADD CONSTRAINT "RideOffer_rideRequestId_fkey" FOREIGN KEY ("rideRequestId") REFERENCES public."RideRequest"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RideRequest RideRequest_passengerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RideRequest"
    ADD CONSTRAINT "RideRequest_passengerId_fkey" FOREIGN KEY ("passengerId") REFERENCES public."Passenger"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RideRequest RideRequest_selectedDriverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RideRequest"
    ADD CONSTRAINT "RideRequest_selectedDriverId_fkey" FOREIGN KEY ("selectedDriverId") REFERENCES public."Driver"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Vehicle Vehicle_driverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Vehicle"
    ADD CONSTRAINT "Vehicle_driverId_fkey" FOREIGN KEY ("driverId") REFERENCES public."Driver"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict kvkr9UJQu5YjtO9Dac62QjgIbr7EZZX0BRQHDGC6ZhVRbmdsek6bTV8T6ueDv1a

